import React from 'react';
import './App.css';
// import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import ListProductComponent from './components/product.component';
import HeaderComponent from './components/header.component';
import FooterComponent from './components/footer.component';
import FormProductComponent from './components/formProduct.component';
import SignInComponents from './components/login.component';
import SignUpComponents from './components/signup.component';

function App() {
  return (
    <div>
        <Router>
              <HeaderComponent />
                <div className="container">
                    <Routes> 
                          <Route path = "/" element = {<ListProductComponent />}></Route>
                          <Route path = "/product/list" element = {<ListProductComponent />}></Route>
                          <Route path = "/product/create/:id" element = {<FormProductComponent />}></Route>
                          <Route path = "/auth/signin" element = {<SignInComponents />}></Route>
                          <Route path = "/auth/signup" element = {<SignUpComponents />}></Route>
                    </Routes>
                </div>
              <FooterComponent />
        </Router>
    </div>
    
  );
}

export default App;